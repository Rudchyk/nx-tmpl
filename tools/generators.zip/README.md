## ZIP generators

`"C:/Program Files/7-Zip/7z.exe" a tools/generators/element.zip ./tools/generators/element/*`
`"C:/Program Files/7-Zip/7z.exe" a tools/generators/redux.zip ./tools/generators/redux/*`
`"C:/Program Files/7-Zip/7z.exe" a tools/generators.zip ./tools/generators/*`
